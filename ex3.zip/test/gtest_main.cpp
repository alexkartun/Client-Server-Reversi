/*
 * gtest_main.cpp
 *	Alex Kartun & Ofir Sharon
 *	324429216   & 204717664
 */
#include "gtest/gtest.h"

GTEST_API_ int main(int argc, char **argv) {
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}




